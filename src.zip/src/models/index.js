const dbConfig = require('../config/db.config');

const {Sequelize, DataTypes} = require('sequelize');

const sequelize = new Sequelize(
    dbConfig.DB,
    dbConfig.USER,
    dbConfig.PASSWORD, {
        host: dbConfig.HOST,
        dialect: dbConfig.dialect,
        operatorsAliases: false,

        pool: {
            max: dbConfig.pool.max,
            min: dbConfig.pool.min,
            acquire: dbConfig.pool.acquire,
            idle: dbConfig.pool.idle

        }
    }
)

sequelize.authenticate()
.then(() => {
    console.log('connected..')
})
.catch(err => {
    console.log('Error'+ err)
})

const db = {}

db.Sequelize = Sequelize
db.sequelize = sequelize

db.users = require('./user.model')(sequelize, DataTypes);
db.products = require('./product.model')(sequelize, DataTypes);
db.reviews = require('./review.model')(sequelize, DataTypes);
db.companys = require('./company.model')(sequelize,DataTypes);
db.tokens = require('./token.model')(sequelize, DataTypes);

db.sequelize.sync({ force: false })
.then(() => {
    console.log('yes re-sync done!');
});


db.users.hasMany(db.companys, {
    foreignKey: 'user_id',
    as: 'companys'
});


db.companys.hasMany(db.products, {
    foreignKey: 'company_id',
    as: 'products'
});

db.products.hasMany(db.reviews, {
    foreignKey: 'product_id',
    as: 'review'
});






module.exports = db;