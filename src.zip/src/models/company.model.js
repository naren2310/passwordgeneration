module.exports = (sequelize, DataTypes) => {

    const Company = sequelize.define("company", {
        companyName: {
            type: DataTypes.STRING,
        },
        address: {
            type: DataTypes.STRING,
        }
    })

    return Company;

}