// import controllers review, products
const productController = require('../controllers/product.controller')



// router
const router = require('express').Router()


// use routers
router.post('/addProduct/:id', productController.addProduct)

router.get('/allProducts', productController.getAllProducts)

router.get('/published', productController.getPublishedProduct)

// get product Reviews
router.get('/getProductReviews/:id', productController.getProductReviews)


// Products router
router.get('/:id', productController.getOneProduct)

router.put('/:id', productController.updateProduct)

router.delete('/:id', productController.deleteProduct)

module.exports = router;