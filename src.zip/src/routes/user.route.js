// import controllers review, products
const userController = require('../controllers/user.controller')



// router
const router = require('express').Router()


// use routers
router.post('/addUser', userController.addUser);

router.post('/login', userController.login);

router.post('/resetPassword', userController.resetPassword);

router.get('/getAllUser', userController.getAllUsers)

router.get('/:id', userController.getOneUser)

router.put('/:id', userController.updateUser)

router.delete('/:id', userController.deleteUser)

module.exports = router;