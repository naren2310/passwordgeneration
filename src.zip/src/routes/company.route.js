// import controllers review, products
const companyController = require('../controllers/company.controller')



// router
const router = require('express').Router()


// use routers
router.post('/addCompany/:id', companyController.addCompany)

router.get('/getAllCompanys', companyController.getAllCompanys)

router.get('/:id', companyController.getOneCompany)

router.put('/:id', companyController.updateCompany)

router.delete('/:id', companyController.deleteCompany)

module.exports = router;