const reviewController = require('../controllers/review.controller')

// router
const router = require('express').Router();



// Review Url and Controller

router.post('/addReview/:id', reviewController.addReview);
router.get('/allReviews', reviewController.getAllReviews);

module.exports = router;