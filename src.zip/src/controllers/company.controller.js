const db = require('../models');


const Company = db.companys;;


// 1. create company

const addCompany = async (req, res) => {

    let payload = {
        user_id: req.params.id,
        companyName: req.body.companyName,
        address: req.body.address,
    }

    const company = await Company.create(payload);
    res.status(200).send(company);

}



// 2. get all data

const getAllCompanys = async (req, res) => {

    let company = await Company.findAll({});
    res.status(200).send(company);

}

// 3. get single Company

const getOneCompany = async (req, res) => {

    let id = req.params.id;
    let company = await Company.findOne({ where: { id: id }});
    res.status(200).send(company);

}

// 4. update Company

const updateCompany = async (req, res) => {

    let id = req.params.id;

    const company = await Company.update(req.body, { where: { id: id }});

    res.status(200).send("sucess");
   

}

// 5. delete product by id

const deleteCompany = async (req, res) => {

    let id = req.params.id;
    
    await Company.destroy({ where: { id: id }} );

    res.status(200).send('Product is deleted !')

}


module.exports = {
    addCompany,
    getAllCompanys,
    getOneCompany,
    updateCompany,
    deleteCompany,
    
}