const express = require('express');
const cors = require('cors');
const rout = require('./routes/product.route');
const route = require('./routes/review.route');
const router = require('./routes/company.route');
const routers = require('./routes/user.route');
const auth = require("./middlewares/auth");
const app = express();

var corOptions = {
    origin: 'http://localhost:8081'
}

//middlewares

app.use(cors(corOptions))
app.use(express.json())
app.use(express.urlencoded({extended:true}))

// routers 

app.use('/api/companys',router)
app.use('/api/products',rout);
app.use('/api/reviews',route);
app.use('/api/users/',routers);

//testing

app.get('/', (req,res)=>{
    res.json({message: 'Hello From API'})
});

app.post("/api/users/", auth, (req, res) => {
    res.status(200).send("Welcome");
  });

  
//port
const PORT = 8085;

// server

app.listen(PORT,()=>{
    console.log(`server is running port ${PORT}`);
})